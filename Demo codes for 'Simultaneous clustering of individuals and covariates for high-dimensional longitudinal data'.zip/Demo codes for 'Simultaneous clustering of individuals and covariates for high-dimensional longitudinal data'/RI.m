function RI=RI(a,b)
x1=0;
x2=0;
x3=0;
x4=0;
m=length(a);
n=length(b);
if(m~=n)
    disp('error!');
else
    for i=1:1:m
        for j=(i+1):1:n
            if((a(i)==a(j))&&(b(i)==b(j)))
                x1=x1+1;
            elseif((a(i)==a(j))&&(b(i)~=b(j)))
                x2=x2+1;
            elseif((a(i)~=a(j))&&(b(i)==b(j)))
                x3=x3+1;
            elseif((a(i)~=a(j))&&(b(i)~=b(j)))
                x4=x4+1;
            end  
        end
    end
    RI=2*(x1+x4)/(m*(m-1));
end